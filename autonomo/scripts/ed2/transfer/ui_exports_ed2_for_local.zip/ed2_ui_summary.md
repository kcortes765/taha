# ED2 UI Summary

## Base Reactions
| Output Case   |       FX |       FY |        MZ |
|:--------------|---------:|---------:|----------:|
| EX            | -637.839 |    0     |  10364.9  |
| EY            |    0     | -637.839 | -10364.9  |
| TEX           |    0     |    0     |  -1508.21 |
| TEY           |    0     |    0     |  -1508.21 |

## Story Forces Bottom
| Story   | Output Case   |       VX |       VY |         T |
|:--------|:--------------|---------:|---------:|----------:|
| Story1  | EX            | -637.839 |    0     |  10364.9  |
| Story2  | EX            | -552.66  |    0     |   8980.73 |
| Story3  | EX            | -470.565 |    0     |   7646.68 |
| Story4  | EX            | -376.466 |    0     |   6117.58 |
| Story5  | EX            | -253.835 |    0     |   4124.82 |
| Story1  | EY            |    0     | -637.839 | -10364.9  |
| Story2  | EY            |    0     | -552.66  |  -8980.73 |
| Story3  | EY            |    0     | -470.565 |  -7646.68 |
| Story4  | EY            |    0     | -376.466 |  -6117.58 |
| Story5  | EY            |    0     | -253.835 |  -4124.82 |

## Drift Condicion 1 (joint/story)
### X
| Story   |   Drift X |
|:--------|----------:|
| Story1  |  0.001165 |
| Story2  |  0.001397 |
| Story3  |  0.001369 |
| Story4  |  0.001116 |
| Story5  |  0.000737 |

### Y
| Story   |   Drift Y |
|:--------|----------:|
| Story1  |  0.001165 |
| Story2  |  0.001397 |
| Story3  |  0.001369 |
| Story4  |  0.001116 |
| Story5  |  0.000737 |

Gobierna X: Story2 con 0.001397

Gobierna Y: Story2 con 0.001397

## Drift Condicion 2 (Max/Avg)
### X
| Story   |   Max Drift |   Avg Drift |   Delta(Max-Avg) |   Ratio |
|:--------|------------:|------------:|-----------------:|--------:|
| Story1  |    0.004079 |    0.003477 |         0.000602 |   1.173 |
| Story2  |    0.004192 |    0.003521 |         0.000671 |   1.191 |
| Story3  |    0.004106 |    0.003408 |         0.000698 |   1.205 |
| Story4  |    0.003349 |    0.002738 |         0.000611 |   1.223 |
| Story5  |    0.002212 |    0.00175  |         0.000462 |   1.264 |

### Y
| Story   |   Max Drift |   Avg Drift |   Delta(Max-Avg) |   Ratio |
|:--------|------------:|------------:|-----------------:|--------:|
| Story1  |    0.004079 |    0.003477 |         0.000602 |   1.173 |
| Story2  |    0.004192 |    0.003521 |         0.000671 |   1.191 |
| Story3  |    0.004106 |    0.003408 |         0.000698 |   1.205 |
| Story4  |    0.003349 |    0.002738 |         0.000611 |   1.223 |
| Story5  |    0.002212 |    0.00175  |         0.000462 |   1.264 |

Ratio max X: Story5 con 1.264

Ratio max Y: Story5 con 1.264

## CM/CR
No disponible en export; usar centro geometrico proxy X=16.25 m, Y=16.25 m.

## Chequeo rapido
- Drift max X <= 0.002: OK
- Drift max Y <= 0.002: OK
- Delta(Max-Avg) max X <= 0.001: OK
- Delta(Max-Avg) max Y <= 0.001: OK